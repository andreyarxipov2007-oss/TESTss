const STORAGE_KEY_S = 'settings';
const STORAGE_KEY_O = 'old'

//Функция изменяет кодировку цвета из rgb в hex
function rgbToHex(rgb) {
  let rgbValues = rgb.match(/\d+/g);
  return "#" + rgbValues.slice(0, 3).map(function(x) {
    return ("0" + parseInt(x).toString(16)).slice(-2);
  }).join("");
}

//Функция сохраняет все изменяемые цвета на странице
function getColor (){
    const rgbhead = window.getComputedStyle(document.querySelector('.head_label')).color;
    const rgbbody = window.getComputedStyle(document.querySelector('body')).backgroundColor;
    const rgbnote = window.getComputedStyle(document.querySelector('.note')).backgroundColor;
    const rgbsite_pages = window.getComputedStyle(document.querySelector('.site_pages')).color;
    // console.log(rgbsite_pages)
    const rgbnotes = window.getComputedStyle(document.querySelector('.notes')).color;
    const mmm = {
        h_color : rgbToHex(rgbhead),
        b_color : rgbToHex(rgbbody),
        n_color : rgbToHex(rgbnote),
        s_color : rgbToHex(rgbsite_pages),
        ns_color : rgbToHex(rgbnotes)
    }
    sessionStorage.setItem(STORAGE_KEY_O, JSON.stringify(mmm));
}

//Функция которая устанавливает input-цвета при переключении на страницу
function setOldColor() {
    const n = sessionStorage.getItem(STORAGE_KEY_O)
    const colors_old = JSON.parse(n)
    // console.log(colors_old)
    const body = colors_old.b_color
    const note = colors_old.n_color
    const site_pages = colors_old.s_color
    const notes = colors_old.ns_color
    const head = colors_old.h_color
    const col_mas = [head, body, note, site_pages, notes]
    
    document.querySelectorAll('.change_color .input_color').forEach((color, index) => {
        color.value = col_mas[index]
    });
}

//Функция сохраненяет цвета из input-цветов
function saveAllColors() {
    const colors = [];
    try {
        document.querySelectorAll('.change_color').forEach((color, index) => {
            const colorData = {
                id: color.id || `color_${index}`,
                title: color.querySelector('span')?.innerText || '',
                values: []
            };
            color.querySelectorAll('.input_color').forEach((val) => {
                // console.log(val.value)
                colorData.values.push(val.value)
            })
            colors.push(colorData);
        });
        sessionStorage.setItem(STORAGE_KEY_S, JSON.stringify(colors));
        // console.log('Цвета сохранены:', colors);
        return true
    }
    catch (error) {
        console.error('ERRORR', error);
        return false;
    }
}

//Функция загружает сохраненные из input-color цвета
function loadAllColor() {
    const savedColors = sessionStorage.getItem(STORAGE_KEY_S);
    console.log(savedColors)
    if (!savedColors) {
        return false;
    }
    try {
        const colors = JSON.parse(savedColors);
        const body = document.querySelector('body');
        const note = document.querySelectorAll('.note');
        const site_pages = document.querySelectorAll('html');
        const notes = document.querySelector('.notes');
        const head = document.querySelector('.head_label');

        head.style.color = colors[0].values
        body.style.backgroundColor = colors[1].values;
        note.forEach((n) => {
            n.style.backgroundColor = colors[2].values;
        })
        site_pages.forEach((page) => {
            page.style.setProperty('--main-color', colors[3].values);
        })
        notes.style.color = colors[4].values;
              
        return true;
    } catch (error) {
        console.error('Ошибка загрузки цветов:', error);
        return false;
    }
}

// Сохраняем при любых изменениях
function setupAutoSave() {
    // // Сохраняем при изменении текста (если есть contenteditable или input)
    document.addEventListener('input', (event) => {
        if (event.target.classList?.contains('input') || event.target.tagName === 'INPUT') {
            setTimeout(saveAllColors, 500);
            setTimeout(loadAllColor, 500);
            console.log('ЦВЕТА СОХРАНЕНЫ')
        }
    });
    
    // Сохраняем перед закрытием/перезагрузкой страницы
    window.addEventListener('beforeunload', () => {
        saveAllColors();
    });
}

// Установление цветов при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(setOldColor(), 100)
    console.log('Используем цвета');
    const loaded = loadAllColor();
    if (!loaded) {
        console.log('Используем цвета по умолчанию');
    }
    setupAutoSave();
});

// Дополнительно сохраняем перед переключением вкладок
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Вкладка скрыта - сохраняем
        saveAllColors();
        getColor()
    } 
});