//Фунция подсчёта количества элементов с указаным атрибутом
function count_input(look){
    let inputs = document.querySelectorAll(look)
    return count = inputs.length
}

// Наблюдатель за 
// Обработка начала перетаскивания
document.addEventListener('dragstart', (e) => {
    // Проверяем, начинается ли ID элемента с "case_" или "case_change_"
    if (e.target.id && (e.target.id.startsWith('case_') || e.target.id.startsWith('case_change_'))) {
        Drag(e); // Вызываем вашу функцию Drag
    }
});

// Разрешаем Drop
document.addEventListener('dragover', (e) => {
    if (e.target.id && (e.target.id.startsWith('case_') || e.target.id.startsWith('case_change_'))) {
        allowDrop(e);
    }
});

// Обработка сброса
document.addEventListener('drop', (e) => {
    if (e.target.id && (e.target.id.startsWith('case_') || e.target.id.startsWith('case_change_'))) {
        Drop(e);
    }
});

const config = {
  attributes: true,
  childList: true,
  subtree: true,}
let target_1 = document.getElementById('popup_window')
observer.observe(target_1, config)
let target_2 = document.getElementById('popup_window_change')
observer.observe(target_2, config)

// Отмена обработки элемента обчным способом
function allowDrop(event) {
    event.preventDefault()
}

// Получаем id перетаскиваемого элемента
function Drag(event) { //
    event.dataTransfer.setData('case_id', event.target.id)
}

// Функция, которая меняет позициями перетаскиваемый объект с объектом, на который перетащили
function Drop(event) {
    let move_div_id = event.dataTransfer.getData('case_id') // move div
    let move_case_data = document.getElementById(move_div_id)
    let drop_input_id = event.target.id // drop input
    let child_drop_case_data = document.getElementById(drop_input_id)
    let drop_case_data = child_drop_case_data.parentNode

    if (move_div_id===drop_input_id || move_case_data.contains(drop_case_data)){
        event.preventDefault();
        console.log('NOOOO')
    }else{
        let drop_next_el = drop_case_data.nextElementSibling
        console.log(drop_next_el)
        console.log(move_case_data)
        move_case_data.before(drop_case_data)
        if (drop_next_el !== move_case_data){
            drop_next_el.before(move_case_data)
        } else{ move_case_data.after(drop_case_data)}
    }
}
