const STORAGE_KEY_U = 'diary_notes';
const STORAGE_KEY_C = 'checkboxx';

// Функция для сохранения всех заметок
function saveAllNotes() {
    const ul = document.getElementById('section')
    const saved_ul = ul.innerHTML
    sessionStorage.setItem(STORAGE_KEY_U, saved_ul);

    const checkb = document.querySelectorAll('input[type="checkbox"]')
    const checkb_val = []
    checkb.forEach((val, index) => {
        const mas = {
            index: index,
            val: val.checked
        }
        checkb_val.push(mas);
    })
    sessionStorage.setItem(STORAGE_KEY_C, JSON.stringify(checkb_val))
}

// Функция для загрузки заметок из localStorage
function loadAllNotes() {
    const saved = sessionStorage.getItem(STORAGE_KEY_U)
    // console.log(saved)
    if (!saved) return;
    try {
        const load_ul = document.getElementById('section');
        if (load_ul) {
            load_ul.innerHTML = saved;
            // console.log('Заметки загружены из HTML:', load_ul);
            return true;
        }
        return false;
    }
    catch (error) {
        console.error('Ошибка загрузки заметок:', error);
        return false;
    }
}

// Функция для восстановления состояния checkbox
function restoreCheckboxesState(){
    const saved_ch = sessionStorage.getItem(STORAGE_KEY_C)
    const j = JSON.parse(saved_ch)
    // console.log(j)
    if (!saved_ch) return;
    try {
        const load_ch = document.querySelectorAll('input[type="checkbox"]');
        // console.log(load_ch)
        if (load_ch) {
            load_ch.forEach( (input, index)  => {
                input.checked = j[index].val
            })
            return true;
        }
        return false;
    } catch (error) {
        console.error('Ошибка загрузки Checkbox:', error);
        return false;
    }
}

// Функция сохраняет заметки при изменениях страницы
function setupAutoSave() {
    // Сохраняет при изменении чекбоксов
    document.addEventListener('change', (event) => {
        if (event.target.type === 'checkbox') {
            setTimeout(saveAllNotes, 100);
        }
    });
    
    // Сохраняет при изменении текста
    document.addEventListener('input', (event) => {
        if (event.target.classList?.contains('input') || event.target.tagName === 'INPUT') {
            setTimeout(saveAllNotes, 100);
        }
    });
    
    // Сохраняет перед закрытием/перезагрузкой страницы
    window.addEventListener('beforeunload', () => {
        saveAllNotes();
    });
    
    // Сохраняет каждые 30 секунд (на всякий случай)
    setInterval(saveAllNotes, 30000);
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Пытаемся загрузить сохраненные заметки
    loadAllNotes();

    // Восстанавливает состояние чекбоксов
    restoreCheckboxesState();
    //Автосохранение
    setupAutoSave();
    setTimeout(saveAllNotes, 500);
});

// Сохраняет заметки при переключении вкладок
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        saveAllNotes();
    }
});