const button_save = document.getElementById("button_save_note")

// Функция создания заметки
function add_note() {
    let date_ = document.getElementById("day")
    let h_date = document.createElement("h2")
    let date_form = date_.value
    let mas = date_form.split('-')
    let year = mas[0]
    let month = mas[1]
    let day = mas[2]
    if (month === '01'){
        month = 'Января'
    }
    if (month === '02'){
        month = 'Февраля'
    }
    if (month === '03'){
        month = 'Марта'
    }
    if (month === '04'){
        month = 'Апреля'
    }
    if (month === '05'){
        month = 'Мая'
    }
    if (month === '06'){
        month = 'Июня'
    }
    if (month === '07'){
        month = 'Июля'
    }
    if (month === '08'){
        month = 'Августа'
    }
    if (month === '09'){
        month = 'Сентября'
    }
    if (month === '10'){
        month = 'Октября'
    }
    if (month === '11'){
        month = 'Ноября'
    }
    if (month === '12'){
        month = 'Декабря'
    }

    h_date.textContent = day +' '+ month +' '+ year

    const inputValues = Array.from(document.querySelectorAll('.case input'), input => input.value);

    //Если заметка с такой датой не существует, то при нажатии Сохранить, заметка создаётся
    if (document.getElementById(`d_${date_form}`) === null) {
        let div_extented = document.createElement("div")
        let note = document.createElement("li")
        div_extented.className = 'div_extented'
        div_extented.id = `div_${date_form}`
        note.className = "note"
        note.id = `d_${date_form}`
        note.append(h_date)
        for (let i = 0; i <= (count_input('[id^="case_input_"]') - 1); i++) {
            let text_case_input = inputValues[i]
            let form = document.createElement("form")
            let table = document.createElement('table')
            let tr = document.createElement('tr')
            let td_checkbox = document.createElement('td')
            let td_label = document.createElement('td')

            td_label.className = 'txt'
            // console.log(text_case_input)
            td_label.textContent = text_case_input
            let input = document.createElement('input')
            input.type = 'checkbox'
            td_checkbox.append(input)
            tr.append(td_checkbox)
            tr.append(td_label)
            table.append(tr)
            form.append(table)
            note.append(form)
            // console.log(inputValues)
        }

        let change = document.createElement('button')
        change.className = 'change'
        change.id = 'button_change'
        change.textContent = 'Изменить'
        note.append(change)
        let button_delete_note = document.createElement('button')
        let button_delete_note_img = document.createElement("img")
        button_delete_note_img.src = 'images/free-icon-cancel-5054047.png'
        button_delete_note.className = 'button_delete_note'
        button_delete_note.append(button_delete_note_img)
        div_extented.append(note)
        div_extented.append(button_delete_note)
        document.getElementById("section").append(div_extented)
    }
    //Если заметка с такой датой уже существует, то при нажатии Сохранить, задачи добавляются в сущетсвующую заметку
    else {
        let note = document.querySelector(`#d_${date_form} .change`)
        // console.log(note)
        for (let i = 0; i <= (count_input('[id^="case_input_"]') - 1); i++) {
            let text_case_input = inputValues[i]
            let form = document.createElement("form")
            let table = document.createElement('table')
            let tr = document.createElement('tr')
            let td_checkbox = document.createElement('td')
            let td_label = document.createElement('td')
            td_label.className = 'txt'
            td_label.textContent = text_case_input
            // console.log(text_case_input)
            let input = document.createElement('input')
            input.type = 'checkbox'
            td_checkbox.append(input)
            tr.append(td_checkbox)
            tr.append(td_label)
            table.append(tr)
            form.append(table)
            note.before(form)
        }
    }
    // console.log(count_input('[id^="case_input_"]'))
}

const button_delete = document.getElementById("button_delete_note")
function delete_note(bbb) {
    // console.log(bbb)
    let div_id_extented_del = bbb.id
    // console.log(div_id_extented_del)
    let di = document.getElementById(div_id_extented_del)
    di.remove()
}

//Если клик по кнопке удаления заметки, вызывается функция delete_note
document.addEventListener('click', async function(event) {
    const button_delete_target = event.target.closest('.button_delete_note');
    // console.log(button_delete_target)
    if (button_delete_target) {
        let button_delet_id = event.target.closest('div .div_extented')
        delete_note(button_delet_id)
    }
})

// Функция add_note запускается при нажатии на кнопку Сохранить
button_save.onclick = add_note
