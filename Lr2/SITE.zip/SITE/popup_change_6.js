// Добавление задачи в окне изменений заметки
function add_case_change_window() {
    let c = count_input('[id^="case_change_input_"]')
    let new_case_change = document.createElement('div')
    let new_input_change = document.createElement('input')

    c+=1
    new_case_change.className = 'case'
    new_case_change.id = `case_change_${c}`
    new_case_change.draggable = true
    new_input_change.className= "input"
    new_input_change.type = 'text'
    new_input_change.id = `case_change_input_${c}`
    new_input_change.name = 'chase'

    let checkbox_add = document.createElement('input')
    checkbox_add.type = 'checkbox'

    new_case_change.append(checkbox_add)
    new_case_change.append(new_input_change)

    let div_add_change = document.getElementById(`case_change_${count_input('[id^="case_change_input_"]')}`)
    
    console.log(div_add_change)
    div_add_change.after(new_case_change)
}

// Удаление задачи в окне изменений заметки
function delete_case_change_window(){
    let del_inp = document.querySelectorAll('.pop_conteiner [id^="case_change_input_"]')
    // console.log(del_inp)
    let len_del_inp = del_inp.length
    // console.log(len_del_inp)
    let del_inp_f = del_inp[len_del_inp-1]
    // console.log(del_inp_f)
    let del_div = del_inp_f.parentNode.id
    // console.log(del_div)
    let d = document.getElementById(del_div)
    d.remove()
}


let popup_window_change = document.getElementById("popup_window_change")
//Функция делает видимым окно изменения заметки
function openPOPchange(){ 
    popup_window_change.style.display = 'flex';
}
//Функция делает невидимым окно изменения заметки
function closePOPchange(){
    popup_window_change.style.display = 'none';
}
//Закрыть окно изменений
const button_close_pop_change = document.getElementById('button_close_popup_change')
button_close_pop_change.onclick = closePOPchange

//Фунция подсчёта количества элементов input в переданом ей объекте
function count_input_1(doc){ 
    let inputss = doc.querySelectorAll('input')
    return count = inputss.length
}

//Функция собирает пары значений checkbox-text, чтобы сохранять состояние задачи(выполнена или нет)
const STORAGE_KEY_C_T = 'li_checkbox_and_text'
function research_checkbox_and_text(id, sign, sign_1){
    const li_checkbox_and_text = document.getElementById(id)
    console.log(li_checkbox_and_text)
    const conteiner_research = []
    let forms = li_checkbox_and_text.querySelectorAll(`${sign}`)
    console.log(forms)
    forms.forEach( (form, index) => {
        const form_check= form.querySelector('input[type=checkbox]')
        const form_text = form.querySelector(sign_1)
        if (form_text.textContent) {
            conteiner_research.push({
                id: index,
                check: form_check.checked,
                text: form_text.textContent
            })
        } else {
            conteiner_research.push({
                id: index,
                check: form_check.checked,
                text: form_text.value
            })
        }
    })
    console.log(conteiner_research)
    sessionStorage.setItem(STORAGE_KEY_C_T, JSON.stringify(conteiner_research))
    console.log(sessionStorage.getItem(STORAGE_KEY_C_T))
}

//Фукция, создаёт окно изменений заметки из элементов заметки
const STORAGE_KEY_D = 'date_of_node'
function change_note(buttons){
    let parent_btn = buttons.parentNode
    let id_parent_btn = parent_btn.id
    research_checkbox_and_text(id_parent_btn, 'form', '.txt')
    sessionStorage.setItem(STORAGE_KEY_D, JSON.stringify(id_parent_btn))
    // console.log(parent_btn)
    let day_change = document.getElementById('day_change')
    // console.log(day_change.value)
    let dd = id_parent_btn.split('d_')[1]
    let datee = new Date(dd).toISOString().slice(0, 10)
    day_change.value = datee
    // console.log(datee + 'EEEEEEEEEEEEEE')

    let li_notes = document.getElementById(id_parent_btn)
    // console.log(li_notes)
    let notes_count = count_input_1(li_notes)
    // console.log(notes_count)

    let array_case_change = Array.from(document.querySelectorAll('.popup_change .case'))
    // console.log(array_case_change)
    array_case_change.sort((g,h) => {
        return parseInt(h.id.split('change_')[1]) - parseInt(g.id.split('change_')[1])
    })
    // console.log(array_case_change)
    let append_after = document.querySelector('.popup_change .section_note_button')
    // console.log(append_after)
    array_case_change.forEach(item => append_after.after(item))


    let popup_window_change_new = document.getElementById('popup_window_change')
    let old_notes_count = popup_window_change_new.getElementsByClassName('case')


    if (old_notes_count.length>notes_count){
        for (let k=old_notes_count.length; k>notes_count; k--){
            document.getElementById(`case_change_${k}`).remove()
        }
    }

    const tdValues = JSON.parse(sessionStorage.getItem(STORAGE_KEY_C_T))
    for (let j=1; j<=notes_count; j++){
        let new_case_change = document.createElement('div')
        let new_input_change = document.createElement('input')
        new_case_change.className = 'case'
        new_case_change.id = `case_change_${j}`
        new_case_change.draggable = true
        new_input_change.className = "input"
        new_input_change.type = 'text'
        new_input_change.id = `case_change_input_${j}`
        new_input_change.name = 'chase'
        // new_input_change.value = tdValues[j-1].value
        let new_checkbox_change = document.createElement('input')
        new_checkbox_change.type = 'checkbox'
        const id_text_checkbox = tdValues.find(f => f.id=== j-1)
        console.log(id_text_checkbox)
        new_checkbox_change.checked = id_text_checkbox.check
        new_input_change.value = id_text_checkbox.text
        new_case_change.append(new_checkbox_change)
        new_case_change.append(new_input_change)
        let div_ad = document.getElementById(`case_change_${j}`)
        if (!div_ad){
            let div_a = document.getElementById(`case_change_${j-1}`)
            div_a.after(new_case_change)
        } 
        else {                
            let div_a1 = document.getElementById(`case_change_${j}`)
            let text_temp = div_a1.querySelector('input[type=text]')
            let checkbox_temp = div_a1.querySelector('input[type=checkbox]')
            const id_text_checkbox = tdValues.find(f => f.id === j - 1)
            console.log('EELLSSEE-----',id_text_checkbox)
            checkbox_temp.checked = id_text_checkbox.check
            text_temp.value = id_text_checkbox.text
        }
    }    
}

//Фунция подсчёта количества элементов c id, начинающимся с case_change_input_, в переданом ей объекте
function count_input_2(find){
    let all_finds = find.querySelectorAll('[id^="case_change_input_"]')
    return all_finds.length
}

const dialog = document.getElementById('error_date_exists')
// Закрывает dialog при клике
dialog.onclick = () => dialog.close()

//Функция создаёт заметку из данных введённых в окне изменений
function save_note() {
    const saved_id_of_current_node = sessionStorage.getItem(STORAGE_KEY_D)
    const da = JSON.parse(saved_id_of_current_node)
    console.log(da)

    let change_date_ = document.getElementById("day_change")
    let head_date = document.createElement("h2")
    let n_date_form = change_date_.value

    //Если уже сущетсвует заметка на эту дату и эта не та заметка, которую мы редактируем, функция показывает уведомление об ошибке и прекращается
    if (document.getElementById(`d_${n_date_form}`) && da!=`d_${n_date_form}`){
        dialog.showModal()
        return
    }
    mas = n_date_form.split('-')
    year = mas[0]
    month = mas[1]
    day = mas[2]
    if (month === '01'){
        month = 'Января'
    }
    if (month === '02'){
        month = 'Февраля'
    }
    if (month === '03'){
        month = 'Марта'
    }
    if (month === '04'){
        month = 'Апреля'
    }
    if (month === '05'){
        month = 'Мая'
    }
    if (month === '06'){
        month = 'Июня'
    }
    if (month === '07'){
        month = 'Июля'
    }
    if (month === '08'){
        month = 'Августа'
    }
    if (month === '09'){
        month = 'Сентября'
    }
    if (month === '10'){
        month = 'Октября'
    }
    if (month === '11'){
        month = 'Ноября'
    }
    if (month === '12'){
        month = 'Декабря'
    }
    head_date.textContent = day +' '+ month +' '+ year

    let popup_window_change_temp = document.getElementById("popup_window_change")

    research_checkbox_and_text('pop_conteiner', '.case', '.input')

    const new_inputValues = JSON.parse(sessionStorage.getItem(STORAGE_KEY_C_T))
    let new_note_id = `d_${n_date_form}`
    let g = document.getElementById(da)
    let da_split = da.split('d_')[1]
    let da_id = 'div_' + da_split
    let gd = document.getElementById(da_id)
    if (!g){
        console.log('NO NOTES')
    }
    console.log(new_note_id)
    console.log(g)
    if (da!=new_note_id){
        g.id = new_note_id
        gd.id = `div_${n_date_form}`
    }
    console.log(g)
    g.innerHTML = ''
    console.log(g)
    g.append(head_date)
    for (let i = 0; i <= (count_input_2(popup_window_change_temp) - 1); i++) {
        const id_text_checkbox_save = new_inputValues.find(f => f.id === i)
        console.log(new_inputValues)
        
        let nform = document.createElement("form")
        let ntable = document.createElement('table')
        let ntr = document.createElement('tr')
        let ntd_checkbox = document.createElement('td')
        let ntd_label = document.createElement('td')
        ntd_label.className = 'txt'
        let ninput = document.createElement('input')
        ninput.type = 'checkbox'
        ninput.checked = id_text_checkbox_save.check
        ntd_label.textContent = id_text_checkbox_save.text
        ntd_checkbox.append(ninput)
        ntr.append(ntd_checkbox)
        ntr.append(ntd_label)
        ntable.append(ntr)
        nform.append(ntable)
        g.append(nform)
        console.log(id_text_checkbox_save)
    }

    let nchange = document.createElement('button')
    nchange.className = 'change'
    nchange.textContent = 'Изменить'
    nchange.id = 'button_change'
    g.append(nchange)

    console.log(count_input('[id^="case_change_input_"]'))
    sessionStorage.setItem(STORAGE_KEY_D, JSON.stringify(new_note_id))
}

//Функция следит за окном изменения заметки
document.addEventListener('click', async function(event) {
    const button_change = event.target.matches('#button_change');
    const button_save_change = event.target.matches('#button_save_note_change');
    const button_add_case_change = event.target.matches('#button_add_case_change')
    const button_delete_case_change = event.target.matches('#button_delete_case_change')
    if (button_change) {
        let button_change_id = event.target.closest('li #button_change')
        change_note(button_change_id)
        openPOPchange()              
    }
    if (button_save_change) {
        // console.log('Изменения сохранены', button_save_change)
        save_note()
    }
    if (button_delete_case_change){
        delete_case_change_window()
        // console.log('Удаление в окне ИЗМЕНЕНИЙ')
    }
    if (button_add_case_change){
        add_case_change_window()
        // console.log('Добавление в окне ИЗМЕНЕНИЙ')
    }
});

