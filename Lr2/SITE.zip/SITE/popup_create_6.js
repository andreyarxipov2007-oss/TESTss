const button_open_pops = document.getElementById("button_open_pop")
const button_close_pops = document.getElementById("button_close_popup")
const popup_window = document.getElementById("popup_window")

//Функция делает видимым окно создания заметки
function openPOP(){
    popup_window.style.display = 'flex';
    document.getElementById('day').valueAsDate = new Date(); //Ставим в input типа date текущую дату
}
//Функция делает невидимым окно создания заметки
function closePOP(){ //уплывает окно
    popup_window.style.display = 'none';
}

button_open_pops.onclick = openPOP;
button_close_pops.onclick = closePOP;

//////////////////////////////////////////////////////////////////
const button_add_case = document.getElementById("button_add_case")
const button_delete_case = document.getElementById("button_delete_case")
const case_ = document.getElementById("case")

// Добавление задачи в окне создания заметки
function add_case() {
    let add_inp = document.querySelectorAll('.pop_conteiner [id^="case_input_"]')
    console.log(add_inp)
    let len_add_inp = add_inp.length
    console.log(len_add_inp)
    let new_case = document.createElement('div')
    let div_note = document.getElementById(`case_input_${len_add_inp}`)
    let new_input = document.createElement('input')
    // i+=1
    new_case.className = 'case'
    new_case.id = `case_${len_add_inp+1}`
    new_case.draggable = true
    new_input.className= "input"
    new_input.type = 'text'
    new_input.id = `case_input_${len_add_inp+1}`
    new_input.name = 'case'
    
    let image = document.createElement('img')
    image.src = 'images/list-symbol-of-three-items-with-2.png'
    new_case.append(image)
    new_case.append(new_input)

    console.log(div_note)
    console.log(count_input('[id^="case_input_"]'))
    let div_add = document.getElementById(`case_${count_input('[id^="case_input_"]')}`)
    
    console.log(div_add)
    div_add.after(new_case)
}

// Удаление задачи в окне создания заметки
function delete_case(){
    let del_inp = document.querySelectorAll('.pop_conteiner [id^="case_input_"]')
    console.log(del_inp)
    let len_del_inp = del_inp.length
    console.log(len_del_inp)
    let del_inp_f = del_inp[len_del_inp-1]
    console.log(del_inp_f)
    let del_div = del_inp_f.parentNode.id
    console.log(del_div)
    let d = document.getElementById(del_div)
    d.remove()
}

button_add_case.onclick = add_case;
button_delete_case.onclick = delete_case;