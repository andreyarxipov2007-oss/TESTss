﻿const dishes = [
  { id: "kasha_risovaya", name: "Каша рисовая", category: "Завтрак", image: "images/kasha_risovaya.jpg", tags: ["Завтрак"], ingredients: ["рис", "молоко", "сахар", "соль"] },
  { id: "kasha_grechnevaya", name: "Каша гречневая", category: "Завтрак", image: "images/kasha_grechnevaya.jpg", tags: ["Завтрак"], ingredients: ["гречка", "вода", "соль"] },
  { id: "kasha_druzhba", name: "Каша дружба", category: "Завтрак", image: "images/kasha_druzhba.jpg", tags: ["Завтрак"], ingredients: ["рис", "гречка", "молоко", "соль"] },
  { id: "kasha_pshennaya", name: "Каша пшенная", category: "Завтрак", image: "images/kasha_pshennaya.jpg", tags: ["Завтрак"], ingredients: ["пшено", "молоко", "сахар", "масло"] },
  { id: "yaichnitsa", name: "Яичница", category: "Завтрак", image: "images/yaichnitsa.jpg", tags: ["Завтрак"], ingredients: ["яйца", "соль", "масло"] },
  { id: "varenye_yaytsa", name: "Вареные яйца", category: "Завтрак", image: "images/varenye_yaytsa.jpg", tags: ["Завтрак"], ingredients: ["яйца", "соль"] },
  { id: "syrniki", name: "Сырники", category: "Завтрак", image: "images/syrniki.jpg", tags: ["Завтрак"], ingredients: ["творог", "яйца", "мука", "сахар"] },
  { id: "tvorog", name: "Творог", category: "Завтрак", image: "images/tvorog.jpg", tags: ["Завтрак"], ingredients: ["творог", "сметана", "сахар"] },
  { id: "omlet", name: "Омлет", category: "Завтрак", image: "images/omlet.jpg", tags: ["Завтрак"], ingredients: ["яйца", "молоко", "соль"] },
  { id: "zapekanka", name: "Запеканка", category: "Завтрак", image: "images/zapekanka.jpg", tags: ["Завтрак"], ingredients: ["творог", "яйца", "манка", "сахар"] },
  { id: "oladushki", name: "Оладушки", category: "Завтрак", image: "images/oladushki.jpg", tags: ["Завтрак"], ingredients: ["мука", "кефир", "яйца", "сахар"] },
  { id: "skrembl", name: "Скрэмбл", category: "Завтрак", image: "images/skrembl.jpg", tags: ["Завтрак"], ingredients: ["яйца", "молоко", "соль", "перец"] },
  { id: "vermicel_moloko", name: "Вермишель на молоке", category: "Завтрак", image: "images/vermicel_moloko.jpg", tags: ["Завтрак"], ingredients: ["вермишель", "молоко", "сахар", "масло"] },
  { id: "ris", name: "Рис", category: "Обед/ужин", image: "images/ris.jpg", tags: ["Обед", "Ужин"], ingredients: ["рис", "вода", "соль"] },
  { id: "grechka", name: "Гречка", category: "Обед/ужин", image: "images/grechka.jpg", tags: ["Обед/ужин"], ingredients: ["гречка", "вода", "соль"] },
  { id: "bulgur", name: "Булгур", category: "Обед/ужин", image: "images/bulgur.jpg", tags: ["Обед/ужин"], ingredients: ["булгур", "вода", "соль"] },
  { id: "makarony", name: "Макароны", category: "Обед/ужин", image: "images/makarony.jpg", tags: ["Обед/ужин"], ingredients: ["макароны", "вода", "соль"] },
  { id: "pyure", name: "Пюре", category: "Обед/ужин", image: "images/pyure.jpg", tags: ["Обед/ужин"], ingredients: ["картофель", "молоко", "масло", "соль"] },
  { id: "zharenaya_kartoshka", name: "Жареная картошка", category: "Обед/ужин", image: "images/zharenaya_kartoshka.jpg", tags: ["Обед/ужин"], ingredients: ["картофель", "масло", "соль", "перец"] },
  { id: "tushenaya_kartoshka", name: "Тушеная картошка", category: "Обед/ужин", image: "images/tushenaya_kartoshka.jpg", tags: ["Обед/ужин"], ingredients: ["картофель", "лук", "морковь", "масло"] },
  { id: "zapech_kartoshka", name: "Запеченный картофель", category: "Обед/ужин", image: "images/zapech_kartoshka.jpg", tags: ["Обед/ужин"], ingredients: ["картофель", "масло", "соль", "специи"] },
  { id: "brokkoli", name: "Брокколи", category: "Обед/ужин", image: "images/brokkoli.jpg", tags: ["Обед/ужин"], ingredients: ["брокколи", "соль", "масло"] },
  { id: "cvetnaya_kapusta", name: "Цветная капуста", category: "Обед/ужин", image: "images/cvetnaya_kapusta.jpg", tags: ["Обед/ужин"], ingredients: ["цветная капуста", "соль", "масло"] },
  { id: "fasol", name: "Фасоль", category: "Обед/ужин", image: "images/fasol.jpg", tags: ["Обед/ужин"], ingredients: ["фасоль", "лук", "морковь", "томатная паста"] },
  { id: "ragu", name: "Рагу", category: "Обед/ужин", image: "images/ragu.jpg", tags: ["Обед/ужин"], ingredients: ["картофель", "мясо", "овощи", "специи"] },
  { id: "chechevitsa", name: "Чечевица", category: "Обед/ужин", image: "images/chechevitsa.jpg", tags: ["Обед/ужин"], ingredients: ["чечевица", "лук", "морковь", "специи"] },
  { id: "meksikanskaya_smes", name: "Мексиканская смесь", category: "Обед/ужин", image: "images/meksikanskaya_smes.jpg", tags: ["Обед/ужин"], ingredients: ["фасоль", "кукуруза", "перец", "специи"] },
  { id: "kuritsa_klyar", name: "Курица в кляре", category: "Обед/ужин", image: "images/kuritsa_klyar.jpg", tags: ["Обед/ужин"], ingredients: ["курица", "яйца", "мука", "специи"] },
  { id: "funchoza", name: "Фунчоза", category: "Обед/ужин", image: "images/funchoza.jpg", tags: ["Обед/ужин"], ingredients: ["фунчоза", "овощи", "соевый соус"] },
  { id: "carbonara", name: "Карбонара", category: "Обед/ужин", image: "images/carbonara.jpg", tags: ["Обед/ужин"], ingredients: ["паста", "бекон", "яйца", "сыр"] },
  { id: "makarony_flotski", name: "Макароны по-флотски", category: "Обед/ужин", image: "images/makarony_flotski.jpg", tags: ["Обед/ужин"], ingredients: ["макароны", "фарш", "лук", "морковь"] },
  { id: "draniki", name: "Драники", category: "Обед/ужин", image: "images/draniki.jpg", tags: ["Обед/ужин"], ingredients: ["картофель", "лук", "яйца", "мука"] },
  { id: "gulyash_kuritsa", name: "Гуляш из курицы", category: "Обед/ужин", image: "images/gulyash_kuritsa.jpg", tags: ["Обед/ужин"], ingredients: ["курица", "лук", "морковь", "томатная паста"] },
  { id: "zharenaya_kuritsa", name: "Жареная курица", category: "Обед/ужин", image: "images/zharenaya_kuritsa.jpg", tags: ["Обед/ужин"], ingredients: ["курица", "специи", "масло"] },
  { id: "varenaya_kuritsa", name: "Вареная курица", category: "Обед/ужин", image: "images/varenaya_kuritsa.jpg", tags: ["Обед/ужин"], ingredients: ["курица", "соль", "лавровый лист"] },
  { id: "kuritsa_teriyaki", name: "Курица терияки", category: "Обед/ужин", image: "images/kuritsa_teriyaki.jpg", tags: ["Обед/ужин"], ingredients: ["курица", "соус терияки", "мед", "чеснок"] },
  { id: "kotleti", name: "Котлеты", category: "Обед/ужин", image: "images/kotleti.jpg", tags: ["Обед/ужин"], ingredients: ["фарш", "лук", "яйца", "хлеб"] },
  { id: "pelmeni", name: "Пельмени", category: "Обед/ужин", image: "images/pelmeni.jpg", tags: ["Обед/ужин"], ingredients: ["мука", "фарш", "лук", "соль"] },
  { id: "vareniki", name: "Вареники", category: "Обед/ужин", image: "images/vareniki.jpg", tags: ["Обед/ужин"], ingredients: ["мука", "творог", "яйца", "сахар"] },
  { id: "golubtsy", name: "Голубцы", category: "Обед/ужин", image: "images/golubtsy.jpg", tags: ["Обед/ужин"], ingredients: ["капуста", "фарш", "рис", "томатная паста"] },
  { id: "kartof_zapekanka", name: "Картофельная запеканка", category: "Обед/ужин", image: "images/kartof_zapekanka.jpg", tags: ["Обед/ужин"], ingredients: ["картофель", "фарш", "лук", "сыр"] },
  { id: "kuritsa_ananas", name: "Курица с ананасом", category: "Обед/ужин", image: "images/kuritsa_ananas.jpg", tags: ["Обед/ужин"], ingredients: ["курица", "ананас", "соус", "специи"] },
  { id: "mak_zapekanka", name: "Макаронная запеканка", category: "Обед/ужин", image: "images/mak_zapekanka.jpg", tags: ["Обед/ужин"], ingredients: ["макароны", "яйца", "сыр", "молоко"] },
  { id: "hotdog", name: "Хот-дог", category: "Обед/ужин", image: "images/hotdog.jpg", tags: ["Обед/ужин"], ingredients: ["булка", "сосиска", "кетчуп", "горчица"] },
  { id: "sup_kuriny", name: "Куриный суп", category: "Супы", image: "images/sup_kuriny.jpg", tags: ["Супы"], ingredients: ["курица", "рис/макароны", "морковь", "лук"] },
  { id: "borshch", name: "Борщ", category: "Супы", image: "images/borshch.jpg", tags: ["Супы"], ingredients: ["свекла", "капуста", "картофель", "мясо"] },
  { id: "goroh_sup", name: "Гороховый суп", category: "Супы", image: "images/goroh_sup.jpg", tags: ["Супы"], ingredients: ["горох", "картофель", "лук", "морковь"] },
  { id: "sup_frikadelki", name: "Суп с фрикадельками", category: "Супы", image: "images/sup_frikadelki.jpg", tags: ["Супы"], ingredients: ["фарш", "картофель", "вермишель", "зелень"] },
  { id: "rassolnik", name: "Рассольник", category: "Супы", image: "images/rassolnik.jpg", tags: ["Супы"], ingredients: ["перловка", "огурцы", "картофель", "морковь"] },
  { id: "salat_ovoshchnoy", name: "Салат с маслом/майонезом", category: "Салаты", image: "images/salat_ovoshchnoy.jpg", tags: ["Салаты"], ingredients: ["овощи по сезону", "масло/майонез"] },
  { id: "salat_ogurtsi_yaytsa", name: "Огурцы + яйцо", category: "Салаты", image: "images/salat_ogurtsi_yaytsa.jpg", tags: ["Салаты"], ingredients: ["огурцы", "яйца", "зелень", "майонез"] },
  { id: "salat_krabovy", name: "Крабовый салат", category: "Салаты", image: "images/salat_krabovy.jpg", tags: ["Салаты"], ingredients: ["крабовые палочки", "кукуруза", "яйца", "майонез"] },
  { id: "salat_cezar", name: "Цезарь", category: "Салаты", image: "images/salat_cezar.jpg", tags: ["Салаты"], ingredients: ["курица", "листья салата", "сухарики", "соус"] },
  { id: "salat_grechesky", name: "Греческий салат", category: "Салаты", image: "images/salat_grechesky.jpg", tags: ["Салаты"], ingredients: ["помидоры", "огурцы", "сыр фета", "оливки"] },
  { id: "salat_olive", name: "Оливье", category: "Салаты", image: "images/salat_olive.jpg", tags: ["Салаты"], ingredients: ["картофель", "колбаса", "горошек", "майонез"] },
  { id: "salat_tunets", name: "Салат с тунцом и яйцом", category: "Салаты", image: "images/salat_tunets.jpg", tags: ["Салаты"], ingredients: ["тунец", "яйца", "лук", "майонез"] },
  { id: "vinegret", name: "Винегрет", category: "Салаты", image: "images/vinegret.jpg", tags: ["Салаты"], ingredients: ["свекла", "картофель", "морковь", "горошек"] },
  { id: "blinchiki_tvorog", name: "Блинчики с творогом", category: "Сладкое", image: "images/blinchiki_tvorog.jpg", tags: ["Сладкое"], ingredients: ["мука", "яйца", "молоко", "сахар", "творог"] },
  { id: "blinchiki_vishnya", name: "Блинчики с вишней", category: "Сладкое", image: "images/blinchiki_vishnya.jpg", tags: ["Сладкое"], ingredients: ["мука", "яйца", "молоко", "сахар"] },
  { id: "blinchiki_myaso", name: "Блинчики с мясом", category: "Сладкое", image: "images/blinchiki_myaso.jpg", tags: ["Сладкое"], ingredients: ["мука", "яйца", "молоко", "сахар"] },
  { id: "sochni", name: "Сочни", category: "Сладкое", image: "images/sochni.jpg", tags: ["Сладкое"], ingredients: ["мука", "творог", "изюм", "сахар"] },
  { id: "mannik", name: "Манник", category: "Сладкое", image: "images/mannik.jpg", tags: ["Сладкое"], ingredients: ["манка", "кефир", "яйца", "сахар"] },
  { id: "sharlotka", name: "Шарлотка", category: "Сладкое", image: "images/sharlotka.jpg", tags: ["Сладкое"], ingredients: ["яблоки", "мука", "яйца", "сахар"] },
  { id: "sendvich_vetchina", name: "Сэндвич с ветчиной", category: "Закуски", image: "images/sendvich_vetchina.jpg", tags: ["Закуски"], ingredients: ["хлеб", "ветчина", "сыр", "масло"] },
  { id: "sendvich_tunets", name: "Сэндвич с тунцом", category: "Закуски", image: "images/sendvich_tunets.jpg", tags: ["Закуски"], ingredients: ["хлеб", "тунец", "яйца", "майонез"] },
  { id: "forel", name: "с форелью и творож. сыром", category: "Закуски", image: "images/forel.jpg", tags: ["Закуски"], ingredients: ["хлеб", "тунец", "яйца", "майонез"] },
  { id: "buter_kolbasa", name: "Бутерброд с колбасой", category: "Закуски", image: "images/buter_kolbasa.jpg", tags: ["Закуски"], ingredients: ["хлеб", "колбаса", "сыр", "масло"] },
  { id: "hachapuri", name: "Хачапури на сковороде", category: "Закуски", image: "images/hachapuri.jpg", tags: ["Закуски"], ingredients: ["мука", "сыр", "яйца", "масло"] }
];

// ключи для хранения данных в localStorage
const storageKeys = {
  selected: "menu-selected-dishes",
  storage: "menu-storage-items"
};

// собирает список всех уникальных ингредиентов
const allProducts = [...new Set(dishes.flatMap(dish => dish.ingredients))];

// получает массив выбранных блюд из localStorage
function getSelectedDishes() {
  try {
    return JSON.parse(localStorage.getItem(storageKeys.selected)) || [];
  } catch {
    return [];
  }
}
// сохраняет выбранные блюда в localStorage
function setSelectedDishes(arr) {
  localStorage.setItem(storageKeys.selected, JSON.stringify(arr));
}

//получает массив продуктов, которые отметил пользователь в своих запасах, из localStorage
function getStorageItems() {
  try {
    return JSON.parse(localStorage.getItem(storageKeys.storage)) || [];
  } catch {
    return [];
  }
}

// сохраняет массив продуктов, которые отметил пользователь в своих запасах, в localStorage
function setStorageItems(items) {
  localStorage.setItem(storageKeys.storage, JSON.stringify(items));
}

// добавляет или удаляет блюдо из выбранных
function toggleDish(dishId) {
  const selected = getSelectedDishes();
  const exists = selected.includes(dishId);
  const updated = exists ? selected.filter((id) => id !== dishId) : [...selected, dishId];
  setSelectedDishes(updated);
  renderPage();
}

// созда HTML для карточки блюда
function createDishCard(dish) {
  const selected = getSelectedDishes();
  const isSelected = selected.includes(dish.id);

  return `
    <article class="dish-card">
      <img src="${dish.image}" alt="${dish.name}" onerror="this.onerror=null;this.src='images/placeholder.svg';">
      <div class="dish-content">
        <h3>${dish.name}</h3>
        <div class="tags">
          ${dish.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
        </div>
        <button class="button ${isSelected ? "secondary" : "primary"}" data-dish-id="${dish.id}" onclick="toggleDish('${dish.id}')">
          ${isSelected ? "Убрать" : "Добавить"}
        </button>
      </div>
    </article>
  `;
}

// обновляет кнопки Добавить/Убрать в карточках 
function updateDishButtons() {
  const selected = getSelectedDishes();
  document.querySelectorAll("[data-dish-id]").forEach((button) => {
    const isSelected = selected.includes(button.dataset.dishId);
    button.className = `button ${isSelected ? "secondary" : "primary"}`;
    button.textContent = isSelected ? "Убрать" : "Добавить";
  });
}

// получает объекты выбранных блюд на основе их id, сохраненных в localStorage  
function getSelectedDishObjects() {
  const selected = getSelectedDishes();
  return dishes.filter((dish) => selected.includes(dish.id));
}

// получает список уникальных продуктов, которые нужны для выбранных блюд, но которых нет в запасах пользователя
function getMissingProducts() {
  const storageItems = getStorageItems();
  const ingredients = getSelectedDishObjects().flatMap((dish) => dish.ingredients);
  return [...new Set(ingredients.filter((item) => !storageItems.includes(item)))];
}

// получает список блюд, для которых все ингредиенты есть в запасах пользователя
function getReadyDishes() {
  const storageItems = getStorageItems();
  return dishes.filter((dish) => dish.ingredients.every((item) => storageItems.includes(item)));
}

// получает список блюд, колличество недостающих ингредиентов которыхё меньше 60%
function getAlmostReadyDishes() {
  const storageItems = getStorageItems();

  return dishes.map((dish) => { 
    const missingIngredients = dish.ingredients.filter((item) => !storageItems.includes(item));
    return {
      ...dish,
      missingIngredients,
      missingRatio: missingIngredients.length / dish.ingredients.length
      };
  }).filter((dish) => dish.missingRatio < 0.6);
}

// рендерит главную страницу
function renderHomePage() {
  const allDishes = document.getElementById("all-dishes");
  if (allDishes && !allDishes.children.length) {
    allDishes.innerHTML = dishes.map((dish) => createDishCard(dish)).join("");
  }
  updateDishButtons();
}

// рендерит страницу корзины
function renderCartPage() {
  const selectedList = document.getElementById("selected-dishes-list");
    const selected = getSelectedDishObjects();
    selectedList.innerHTML = selected.length ? 
    selected.map((dish) => 
      `
        <div class="list-item">
          <div class="cart-dish-item">
            <img class="cart-dish-image" src="${dish.image}" alt="${dish.name}" onerror="this.onerror=null;this.src='images/placeholder.svg';">
            <div>
              <strong>${dish.name}</strong>
              <span>Нужные продукты: ${dish.ingredients.join(", ")}</span>
            </div>
          </div>
        </div>
      `
    ).join(""): '<div class="empty-state">Вы пока не добавили ни одного блюда.</div>';

  const shoppingList = document.getElementById("shopping-list");
  if (shoppingList) {
    const missing = getMissingProducts();
    shoppingList.innerHTML = missing.length? 
    missing.map((item) => 
      `
        <div class="list-item">
          <strong>${item}</strong>
        </div>
      `
    ).join("") : '<div class="empty-state">Список покупок пока пуст. Вы еще не выбрали блюда или все продукты уже есть дома.</div>';
  }

  const clearButton = document.getElementById("clear-dishes");
    clearButton.onclick = () => {
      setSelectedDishes([]);
      renderPage();
  }
}

function renderStoragePage() {
  const storageBoxContent = document.getElementById("storage-box-content");
  const storageSearch = document.getElementById("storage-search");
  const storageSelectedList = document.getElementById("storage-selected-list");
  const storageSearchResults = document.getElementById("storage-search-results");

  function addStorageItem(item) {
    setStorageItems([...new Set([...getStorageItems(), item])]);
    renderPage();
  }

  function removeStorageItem(item) {
    setStorageItems(getStorageItems().filter((current) => current !== item));
    renderPage();
  }

  function renderSelectedStorageItems() {
    if (!storageSelectedList) {
      return;
    }

    const storageItems = getStorageItems();
    storageSelectedList.innerHTML = storageItems.length?
    storageItems.map((item) => 
      `
        <div class="storage-product-row">
          <span>${item}</span>
          <button class="button secondary" type="button" onclick="removeStorageItem('${item}')">×</button>
        </div>
      `
      ).join(""): '<div class="empty-state">Пока ничего не добавлено в запасы.</div>';
  }

  function renderStorageSearchResults() {
    if (!storageSearchResults) {
      return;
    }

    const query = storageSearch ? storageSearch.value.trim().toLowerCase() : "";
    storageSearchResults.hidden = query.length === 0;

    if (!query.length) {
      storageSearchResults.innerHTML = "";
      return;
    }
    
    const storageItems = getStorageItems();
    const availableProducts = allProducts.filter((item) => !storageItems.includes(item));
    const filteredProducts = availableProducts.filter((item) => item.toLowerCase().includes(query)).slice(0, 12);
    
    storageSearchResults.innerHTML = filteredProducts.length
      ? filteredProducts.map((item) => 
        `
          <div class="storage-product-row">
            <span>${item}</span>
            <button class="button primary" type="button" onclick="addStorageItem('${item.replace(/'/g, "\\'")}')">+</button>
          </div>
        `
      ).join(""): '<div class="empty-state">Ничего не найдено.</div>';
  }

  if (storageSearch) {
    storageSearch.oninput = renderStorageSearchResults;
  }

  window.addStorageItem = addStorageItem;
  window.removeStorageItem = removeStorageItem;

  renderSelectedStorageItems();
  renderStorageSearchResults();

  const availableDishes = document.getElementById("available-dishes");
  if (availableDishes) {
    const almostReady = getAlmostReadyDishes();
    const selectedDishIds = getSelectedDishes();
    availableDishes.innerHTML = almostReady.length
      ? almostReady.map((dish) => 
        `
          <div class="list-item">
            <div class="suggestion-card">
              <img class="suggestion-card-image" src="${dish.image}" alt="${dish.name}" onerror="this.onerror=null;this.src='images/placeholder.svg';">
              <div class="suggestion-card-body">
                <strong>${dish.name}</strong>
                <span class="suggestion-meta">Не хватает: ${dish.missingIngredients.join(", ")}.</span>
                <div class="suggestion-actions">
                  <button class="button ${selectedDishIds.includes(dish.id) ? "secondary" : "primary"}" type="button" onclick="toggleDish('${dish.id}')">
                    ${selectedDishIds.includes(dish.id) ? "Уже в корзине" : "Добавить в корзину"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        `
      ).join(""): '<div class="empty-state">Пока не хватает ингредиентов для приготовления блюд.</div>';
  }
  const clearButton = document.getElementById("clear-items");
    clearButton.onclick = () => {
      setStorageItems([]);
      renderPage();
  }
}

function renderPage() {
  const page = document.body.dataset.page;

  if (page === "home") {
    renderHomePage();
  }

  if (page === "storage") {
    renderStoragePage();
  }

  if (page === "cart") {
    renderCartPage();
  }
}

renderPage();