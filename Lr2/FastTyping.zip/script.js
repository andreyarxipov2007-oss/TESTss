﻿const STORAGE_KEY = 'fastTypingUnlockedLevel';

const state = {
  mode: 'level',
  unlockedLevel: 0,
  currentLevel: 0,
  targetText: '',
  position: 0,
  hasErrorAtCurrent: false,
  attempts: 0,
  mistakes: 0,
  isArmed: false,
  started: false,
  finished: false,
  startTime: 0,
  endTime: 0
};

const navLinks = document.querySelectorAll('.nav-link');
const sections = document.querySelectorAll('.page-section');
const goToTrainingBtn = document.getElementById('goToTrainingBtn');

const modeLabel = document.getElementById('modeLabel');
const levelLabel = document.getElementById('levelLabel');
const trainingInstruction = document.getElementById('trainingInstruction');
const typingArea = document.getElementById('typingArea');
const startOverlay = document.getElementById('startOverlay');
const textDisplay = document.getElementById('textDisplay');

const progressBar = document.getElementById('progressBar');
const progressText = document.getElementById('progressText');

const retryBtn = document.getElementById('retryBtn');
const nextLevelBtn = document.getElementById('nextLevelBtn');
const resetProgressBtn = document.getElementById('resetProgressBtn');

const resultCard = document.getElementById('resultCard');
const resultMessage = document.getElementById('resultMessage');
const finalWpm = document.getElementById('finalWpm');
const finalCpm = document.getElementById('finalCpm');
const finalAccuracy = document.getElementById('finalAccuracy');
const finalErrors = document.getElementById('finalErrors');
const finalTime = document.getElementById('finalTime');

const customTextInput = document.getElementById('customTextInput');
const useCustomTextBtn = document.getElementById('useCustomTextBtn');
const customWarning = document.getElementById('customWarning');

// старт
init();

// инициализация
function init() {
  if (!Array.isArray(window.levels) || window.levels.length === 0) {
    textDisplay.textContent = 'Не удалось загрузить уровни. Проверьте levels.js.';
    return;
  }

  state.unlockedLevel = loadUnlockedLevel();
  state.currentLevel = state.unlockedLevel;

  bindEvents();
  openLevel(state.currentLevel);
  switchSection('home');
}

// события
function bindEvents() {
  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      switchSection(link.dataset.section);
    });
  });

  goToTrainingBtn.addEventListener('click', () => {
    if (state.mode !== 'level') {
      openLevel(state.unlockedLevel);
    }
    switchSection('training');
  });

  typingArea.addEventListener('click', armTraining);
  document.addEventListener('keydown', handleKeydown);

  retryBtn.addEventListener('click', restartCurrentSession);

  nextLevelBtn.addEventListener('click', () => {
    if (state.currentLevel < window.levels.length - 1) {
      openLevel(state.currentLevel + 1);
    }
  });

  resetProgressBtn.addEventListener('click', resetProgress);
  useCustomTextBtn.addEventListener('click', startCustomTraining);
}

// переключение вкладок
function switchSection(sectionId) {
  sections.forEach((section) => {
    section.classList.toggle('active', section.id === sectionId);
  });

  navLinks.forEach((link) => {
    link.classList.toggle('active', link.dataset.section === sectionId);
  });
}

// запуск уровня
function openLevel(levelIndex) {
  state.mode = 'level';
  state.currentLevel = clampLevel(levelIndex);
  state.targetText = String(window.levels[state.currentLevel] || '').replace(/\r/g, '');

  modeLabel.textContent = 'Уровень';
  levelLabel.textContent = String(state.currentLevel + 1);
  trainingInstruction.textContent =
    'Нажмите на блок с текстом, затем печатайте строго по символам.';

  resetSessionState();
}

// запуск своего текста
function startCustomTraining() {
  const userText = customTextInput.value.replace(/\r/g, '');

  if (!userText.trim()) {
    customWarning.classList.remove('hidden');
    return;
  }

  customWarning.classList.add('hidden');

  state.mode = 'custom';
  state.targetText = userText;

  modeLabel.textContent = 'Свой текст';
  levelLabel.textContent = '—';
  trainingInstruction.textContent =
    'Режим своего текста. Ошибки исправляйте Backspace.';

  resetSessionState();
  switchSection('training');
}

// сброс текущей сессии
function resetSessionState() {
  state.position = 0;
  state.hasErrorAtCurrent = false;
  state.attempts = 0;
  state.mistakes = 0;
  state.isArmed = false;
  state.started = false;
  state.finished = false;
  state.startTime = 0;
  state.endTime = 0;

  typingArea.classList.add('blurred');
  startOverlay.classList.remove('hidden');

  resultCard.classList.add('hidden');
  nextLevelBtn.classList.add('hidden');

  renderText();
  updateProgress();
}

// активация тренировки
function armTraining() {
  if (state.finished || !state.targetText) {
    return;
  }

  state.isArmed = true;
  typingArea.classList.remove('blurred');
  startOverlay.classList.add('hidden');
  typingArea.focus();
}

// обработка ввода
function handleKeydown(event) {
  const isTrainingOpen = document.getElementById('training').classList.contains('active');

  if (!isTrainingOpen || !state.isArmed || state.finished) {
    return;
  }

  if (event.ctrlKey || event.metaKey || event.altKey) {
    return;
  }

  if (event.key === 'Backspace') {
    event.preventDefault();
    handleBackspace();
    return;
  }

  const typedChar = normalizeKey(event);
  if (typedChar === null) {
    return;
  }

  event.preventDefault();

  if (!state.started) {
    state.started = true;
    state.startTime = Date.now();
  }

  const expectedChar = state.targetText[state.position];
  state.attempts += 1;

  if (typedChar === expectedChar) {
    state.position += 1;
    state.hasErrorAtCurrent = false;

    if (state.position === state.targetText.length) {
      finishSession();
      return;
    }
  } else {
    state.hasErrorAtCurrent = true;
    state.mistakes += 1;
  }

  renderText();
  updateProgress();
}

// исправление ошибки
function handleBackspace() {
  if (!state.started || state.finished) {
    return;
  }

  if (state.hasErrorAtCurrent) {
    state.hasErrorAtCurrent = false;
  } else if (state.position > 0) {
    state.position -= 1;
  }

  renderText();
  updateProgress();
}

// завершение и подсчёт
function finishSession() {
  state.finished = true;
  state.endTime = Date.now();

  renderText();
  updateProgress();

  const elapsedSeconds = Math.max(1, Math.round((state.endTime - state.startTime) / 1000));
  const minutes = elapsedSeconds / 60;
  const correctChars = state.targetText.length;

  const wpm = Math.round((correctChars / 5) / minutes);
  const cpm = Math.round(correctChars / minutes);
  const accuracy = state.attempts > 0
    ? ((state.attempts - state.mistakes) / state.attempts) * 100
    : 100;

  showResult({
    wpm,
    cpm,
    accuracy,
    errors: state.mistakes,
    elapsedSeconds
  });

  if (state.mode === 'level') {
    unlockNextLevel();

    if (state.currentLevel < window.levels.length - 1) {
      nextLevelBtn.classList.remove('hidden');
    }
  }
}

// вывод результата
function showResult(stats) {
  finalWpm.textContent = String(stats.wpm);
  finalCpm.textContent = String(stats.cpm);
  finalAccuracy.textContent = `${stats.accuracy.toFixed(1)}%`;
  finalErrors.textContent = String(stats.errors);
  finalTime.textContent = formatTime(stats.elapsedSeconds);

  if (stats.accuracy >= 95) {
    resultMessage.textContent = 'Отлично!';
  } else if (stats.accuracy >= 85) {
    resultMessage.textContent = 'Хороший результат.';
  } else {
    resultMessage.textContent = 'Попробуйте ещё раз, чтобы улучшить скорость.';
  }

  resultCard.classList.remove('hidden');
}

// кнопка "ещё раз"
function restartCurrentSession() {
  if (state.mode === 'level') {
    openLevel(state.currentLevel);
  } else {
    modeLabel.textContent = 'Свой текст';
    levelLabel.textContent = '—';
    resetSessionState();
  }
}

// сброс прогресса
function resetProgress() {
  const shouldReset = window.confirm('Сбросить прогресс уровней?');
  if (!shouldReset) {
    return;
  }

  state.unlockedLevel = 0;
  localStorage.setItem(STORAGE_KEY, '0');

  if (state.mode === 'level') {
    openLevel(0);
  }
}

// открытие следующего уровня
function unlockNextLevel() {
  const nextLevel = state.currentLevel + 1;

  if (nextLevel >= window.levels.length) {
    return;
  }

  if (nextLevel > state.unlockedLevel) {
    state.unlockedLevel = nextLevel;
    localStorage.setItem(STORAGE_KEY, String(state.unlockedLevel));
  }
}

// отрисовка текста
function renderText() {
  const fragment = document.createDocumentFragment();

  for (let i = 0; i < state.targetText.length; i += 1) {
    const span = document.createElement('span');
    span.classList.add('char');
    span.textContent = state.targetText[i];

    if (i < state.position) {
      span.classList.add('correct');
    } else if (i === state.position && !state.finished) {
      span.classList.add(state.hasErrorAtCurrent ? 'error' : 'pending');
      span.classList.add('current');
    } else {
      span.classList.add('pending');
    }

    fragment.appendChild(span);
  }

  textDisplay.innerHTML = '';
  textDisplay.appendChild(fragment);
}

// прогресс-бар
function updateProgress() {
  const progress = state.targetText.length > 0
    ? Math.round((state.position / state.targetText.length) * 100)
    : 0;

  progressBar.style.width = `${progress}%`;
  progressText.textContent = `Прогресс: ${progress}%`;
}

// преобразование клавиши
function normalizeKey(event) {
  if (event.key === 'Enter') {
    return '\n';
  }

  if (event.key === 'Tab') {
    return '\t';
  }

  if (event.key.length === 1) {
    return event.key;
  }

  return null;
}

// загрузка прогресса
function loadUnlockedLevel() {
  const raw = Number(localStorage.getItem(STORAGE_KEY));

  if (!Number.isInteger(raw) || raw < 0) {
    return 0;
  }

  return Math.min(raw, window.levels.length - 1);
}

// ограничение номера уровня
function clampLevel(levelIndex) {
  if (!Number.isInteger(levelIndex)) {
    return 0;
  }

  if (levelIndex < 0) {
    return 0;
  }

  if (levelIndex > state.unlockedLevel) {
    return state.unlockedLevel;
  }

  return Math.min(levelIndex, window.levels.length - 1);
}

// формат времени
function formatTime(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
  const seconds = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
  return `${minutes}:${seconds}`;
}
